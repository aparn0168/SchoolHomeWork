﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using VB = Microsoft.VisualBasic;

namespace _20211026TEST
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //string input = VB.Interaction.InputBox("請輸入密碼(甲(乙)月日),甲1026/乙1026","密碼管控");
            //string date = System.DateTime.Now.ToString();
            //string mon_day = date.Substring(5, 2) + date.Substring(8, 2);

            //if (input != "甲" + mon_day && input != "乙" + mon_day) this.Close();
        }
        Random rn = new Random();
        private string[] alldata = new string[1000];
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if(int.TryParse(textBox1.Text, out int result))
            {
                int nth = result;
                data.Items.Clear();
                
                for (int i = 1; i <= nth; i++)
                {
                    alldata[i] = i + ".";
                    alldata[i] += ((char)rn.Next(65, 91)).ToString();
                    alldata[i] += rn.Next(1, 3);
                    for (int j = 0; j < 8; j++)
                    {
                        alldata[i] += rn.Next(0, 10);
                    }
                    alldata[i] += "@";
                    int point = rn.Next(1, 5);
                    switch (point)
                    {
                        case 1:
                            alldata[i] += "A";
                            break;
                        case 2:
                            alldata[i] += "B";
                            break;
                        case 3:
                            alldata[i] += "O";
                            break;
                        case 4:
                            alldata[i] += "AB";
                            break;
                    }
                    alldata[i] += "#";
                    alldata[i] += rn.Next(1, 106);
                }
                data.Items.Add("身分證字號[第1碼大寫英文字母，第2碼1(男)2(女)，餘者8碼(0-9)]@血型#年齡[1,105]");
                for (int i = 1; i <= nth; i++)
                {
                    data.Items.Add(alldata[i]);
                }
            }
            
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            output.Clear();
            int nth = 0;
            if (int.TryParse(textBox1.Text, out int result))
            {
                nth = result;
            }

                switch (comboBox1.Text)
            {
                case "A":
                    for (int i = 1; i <= nth; i++)
                    {
                        int first = alldata[i].IndexOf("@");
                        int last = alldata[i].IndexOf("#");
                        string blood = alldata[i].Substring(first + 1, last - first -1);

                        if(blood == "A")
                        {
                            output.Text += alldata[i] + "\r\n";
                        }
                    }
                    break;
                case "B":
                    for (int i = 1; i <= nth; i++)
                    {
                        int first = alldata[i].IndexOf("@");
                        int last = alldata[i].IndexOf("#");
                        string blood = alldata[i].Substring(first + 1, last - first - 1);

                        if (blood == "B")
                        {
                            output.Text += alldata[i] + "\r\n";
                        }
                    }
                    break;
                case "O":
                    for (int i = 1; i <= nth; i++)
                    {
                        int first = alldata[i].IndexOf("@");
                        int last = alldata[i].IndexOf("#");
                        string blood = alldata[i].Substring(first + 1, last - first - 1);

                        if (blood == "O")
                        {
                            output.Text += alldata[i] + "\r\n";
                        }
                    }
                    break;
                case "AB":
                    for (int i = 1; i <= nth; i++)
                    {
                        int first = alldata[i].IndexOf("@");
                        int last = alldata[i].IndexOf("#");
                        string blood = alldata[i].Substring(first + 1, last - first - 1);

                        if (blood == "AB")
                        {
                            output.Text += alldata[i] + "\r\n";
                        }
                    }
                    break;
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            output.Clear();

            int nth = 0;
            if (int.TryParse(textBox1.Text, out int result))
            {
                nth = result;
            }

            switch (comboBox2.Text)
            {
                case "新竹縣[J] | 新竹市[O] & (血型 & 未成年[年齡 < 18])":
                    for (int i = 1; i <= nth; i++)
                    {
                        int first = alldata[i].IndexOf(".");
                        int last = alldata[i].IndexOf("#");
                        string city = alldata[i].Substring(first + 1, 1);
                        string age = alldata[i].Substring(last + 1);

                        if (int.Parse(age) < 18)
                        {
                            if(city == "J" || city == "O")
                            {
                                output.Text += alldata[i] + "\r\n";
                            }
                        }
                    }
                    break;
            }
        }

        private void comboBox2_SelectionChangeCommitted(object sender, EventArgs e)
        {
            
        }
    }
}
