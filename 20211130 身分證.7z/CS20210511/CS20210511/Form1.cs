﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace CS20210511
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Random Rn = new Random();   

        string[] wh1 = new string[27] {"","台北市","台中市","基隆市","台南市","高雄市",
                                          "台北縣","宜蘭縣","桃園縣","新竹縣","苗栗縣",
                                          "台中縣","南投縣","彰化縣","雲林縣","嘉義縣",
                                          "台南縣","高雄縣","屏東縣","花蓮縣","台東縣",
                                          "澎湖縣","陽明山","金門縣","連江縣","嘉義市",
                                          "新竹市"};
        string[] wh2 = new string[27] {"","A","B","C","D","E",
                                          "F","G","H","J","K",
                                          "L","M","N","P","Q",
                                          "R","S","T","U","V",
                                          "X","Y","W","Z","I",
                                          "O"};       
        int[] IDCode = { 0, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22,
                         23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35};

        private void button1_Click(object sender, EventArgs e)
        {
            if (Verify(input.Text) == "1")
            {
                text_ans.ForeColor = Color.Blue;

                for(int i =1; i<= 26; i++)
                {
                    if(input.Text.Substring(0,1) == wh2[i])
                    {
                        text_ans.Text = "這是正確的{" + wh1[i] + "}地區";
                    }
                }
                if(input.Text.Substring(1,1) == "1") text_ans.Text += "{男性}身分證號碼";
                else text_ans.Text += "{女性}身分證號碼";

                switch (input.Text.Substring(2,1))
                {
                    case "0":
                    case "1":
                    case "2":
                    case "3":
                    case "4":
                    case "5":
                        text_ans.Text += "{其他}人民";
                        break;
                    case "6":
                        text_ans.Text += "{取得國籍之外國人}人民";
                        break;
                    case "7":
                        text_ans.Text += "{無戶籍國民}人民";
                        break;
                    case "8":
                        text_ans.Text += "{港澳居民}人民";
                        break;
                    case "9":
                        text_ans.Text += "{大陸地區}人民";
                        break;
                }
            }
            else
            {
                text_ans.ForeColor = Color.Red;
                text_ans.Text = Verify(input.Text);
            }
        }

        private void CREA_Click(object sender, EventArgs e)
        {
            for(int i =0; i< 27; i++)
            {
                if (WHERE.SelectedIndex == i) break;
                else if (i == 26) return;           
            }

            string ans = null , str = null;
            
            ans = (wh2[WHERE.SelectedIndex +1]).ToString(); //英文
            
            

            if (BOY.Checked) ans += "1";   //第2碼
            else if (GIRL.Checked) ans += "2";

            if (three_chance.SelectedIndex == 0) ans += Rn.Next(0, 6);
            else if (three_chance.SelectedIndex == 1) ans += 6;
            else if (three_chance.SelectedIndex == 2) ans += 7;
            else if (three_chance.SelectedIndex == 3) ans += 8;
            else if (three_chance.SelectedIndex == 4) ans += 9;

            for (int j = 1; j <= 6; j++) // 3-8碼
            {
                ans += Rn.Next(0, 10);
            }

            //做修改
            for (int i = 1; i < 27; i++)
            {
                str += wh2[i];
            }
            int chance1 = IDCode[str.IndexOf(ans.Substring(0, 1)) + 1];
            int total = 0;
            int point = 8;

            total = (chance1 / 10) * 1 + (chance1 % 10) * 9;

            for (int i = 1; i <= 8; i++)
            {
                total += int.Parse(ans.Substring(i, 1)) * point;
                point--;
            }

          
            if (total % 10 == 0) CR_answer.Text = ans + "0";
            else CR_answer.Text = ans + (10 - (total % 10));

        }

        private string Verify(string input)
        {
            bool one = false, two = false , three = false;
            string str = null;
            if (input.Length != 10) return "輸入未達10碼";
            for(int i =1; i<27; i++) 
            {
                if (input.Substring(0, 1) == wh2[i])//驗證第1碼
                {
                    one = true;
                    break;
                }
                else
                {
                    if (i == 26) return "第一碼必須為大寫字母。";                   
                }
            }
            for (int i = 1; i < 27; i++)
            {
                if (input.Substring(1, 1) == "1" || input.Substring(1, 1) == "2")//驗證第2碼
                {
                    for (int j = 2; j < 10; j++)
                    {
                        if (int.TryParse(input.Substring(j, 1), out int result)) //驗證其他號碼是否為數字
                        {
                            two = true;
                        }
                        else
                        {
                            two = false;
                        }
                    }
                }
                else
                {
                    if (i == 26) return "第二碼僅限男(1)女(2)。";
                }
            }
            for (int i = 1; i <27; i++)
            {
                str += wh2[i];
            }


            //規則驗證
            int chance1 = IDCode[str.IndexOf(input.Substring(0, 1)) +1];           
            int total = 0;
            int point = 8;

            total = (chance1 / 10) * 1 + (chance1 % 10) * 9;

            for (int i = 1; i <= 8; i++)
            {
                total += int.Parse(input.Substring(i, 1)) * point;
                point--;
            }

            total += int.Parse(input.Substring(9, 1));

            if (total % 10 == 0) three = true;


            if (one && two && three) return "1";
            return "身分證字號驗證 < 錯誤 > ";
        }

        private void END_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CUT_Click(object sender, EventArgs e)
        {
            Clipboard.SetDataObject(CR_answer.Text);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            input.Text = (String)Clipboard.GetDataObject().GetData(DataFormats.Text);
        }
    }
    }

