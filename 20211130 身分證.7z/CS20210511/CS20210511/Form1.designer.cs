﻿
namespace CS20210511
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.text_ans = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.input = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.GIRL = new System.Windows.Forms.RadioButton();
            this.BOY = new System.Windows.Forms.RadioButton();
            this.WHERE = new System.Windows.Forms.ComboBox();
            this.CUT = new System.Windows.Forms.Button();
            this.CREA = new System.Windows.Forms.Button();
            this.CR_answer = new System.Windows.Forms.TextBox();
            this.END = new System.Windows.Forms.Button();
            this.three_chance = new System.Windows.Forms.ComboBox();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button2);
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.text_ans);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.input);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(34, 48);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(6);
            this.groupBox2.Size = new System.Drawing.Size(735, 289);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "{功能1} 確認現有的身分證字號";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(297, 42);
            this.button2.Margin = new System.Windows.Forms.Padding(6);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(150, 46);
            this.button2.TabIndex = 5;
            this.button2.Text = "貼上";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(297, 100);
            this.button1.Margin = new System.Windows.Forms.Padding(6);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(150, 46);
            this.button1.TabIndex = 4;
            this.button1.Text = "驗證";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // text_ans
            // 
            this.text_ans.Location = new System.Drawing.Point(25, 225);
            this.text_ans.Margin = new System.Windows.Forms.Padding(6);
            this.text_ans.MaxLength = 300;
            this.text_ans.Name = "text_ans";
            this.text_ans.ReadOnly = true;
            this.text_ans.Size = new System.Drawing.Size(676, 33);
            this.text_ans.TabIndex = 3;
            this.text_ans.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 174);
            this.label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(200, 24);
            this.label2.TabIndex = 2;
            this.label2.Text = "身分證字號之驗證結果";
            // 
            // input
            // 
            this.input.Location = new System.Drawing.Point(25, 100);
            this.input.Margin = new System.Windows.Forms.Padding(6);
            this.input.MaxLength = 10;
            this.input.Name = "input";
            this.input.Size = new System.Drawing.Size(196, 33);
            this.input.TabIndex = 1;
            this.input.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 60);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(217, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "請輸入身分證字號(10字)";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.three_chance);
            this.groupBox3.Controls.Add(this.groupBox1);
            this.groupBox3.Controls.Add(this.WHERE);
            this.groupBox3.Controls.Add(this.CUT);
            this.groupBox3.Controls.Add(this.CREA);
            this.groupBox3.Controls.Add(this.CR_answer);
            this.groupBox3.Location = new System.Drawing.Point(34, 369);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(6);
            this.groupBox3.Size = new System.Drawing.Size(596, 278);
            this.groupBox3.TabIndex = 6;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "{功能2} 產生一組新的身分證字號";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.GIRL);
            this.groupBox1.Controls.Add(this.BOY);
            this.groupBox1.ForeColor = System.Drawing.Color.Black;
            this.groupBox1.Location = new System.Drawing.Point(35, 169);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 100);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "請選擇性別";
            // 
            // GIRL
            // 
            this.GIRL.AutoSize = true;
            this.GIRL.ForeColor = System.Drawing.Color.Red;
            this.GIRL.Location = new System.Drawing.Point(125, 35);
            this.GIRL.Margin = new System.Windows.Forms.Padding(6);
            this.GIRL.Name = "GIRL";
            this.GIRL.Size = new System.Drawing.Size(66, 28);
            this.GIRL.TabIndex = 4;
            this.GIRL.TabStop = true;
            this.GIRL.Text = "女生";
            this.GIRL.UseVisualStyleBackColor = true;
            // 
            // BOY
            // 
            this.BOY.AutoSize = true;
            this.BOY.Checked = true;
            this.BOY.ForeColor = System.Drawing.Color.Blue;
            this.BOY.Location = new System.Drawing.Point(20, 35);
            this.BOY.Margin = new System.Windows.Forms.Padding(6);
            this.BOY.Name = "BOY";
            this.BOY.Size = new System.Drawing.Size(66, 28);
            this.BOY.TabIndex = 3;
            this.BOY.TabStop = true;
            this.BOY.Text = "男生";
            this.BOY.UseVisualStyleBackColor = true;
            // 
            // WHERE
            // 
            this.WHERE.FormattingEnabled = true;
            this.WHERE.Items.AddRange(new object[] {
            "台北市A",
            "台中市B",
            "基隆市C",
            "台南市D",
            "高雄市E",
            "台北縣F",
            "宜蘭縣G",
            "桃園縣H",
            "新竹縣J",
            "苗栗縣K",
            "台中縣L",
            "南投縣M",
            "彰化縣N",
            "雲林縣P",
            "嘉義縣Q",
            "台南縣R",
            "高雄縣S",
            "屏東縣T",
            "花蓮縣U",
            "台東縣V",
            "澎湖縣X",
            "陽明山Y",
            "金門縣W",
            "連江縣Z",
            "嘉義市I",
            "新竹市O"});
            this.WHERE.Location = new System.Drawing.Point(35, 115);
            this.WHERE.Margin = new System.Windows.Forms.Padding(6);
            this.WHERE.Name = "WHERE";
            this.WHERE.Size = new System.Drawing.Size(238, 32);
            this.WHERE.TabIndex = 5;
            this.WHERE.Text = "請選擇地區";
            // 
            // CUT
            // 
            this.CUT.Location = new System.Drawing.Point(424, 36);
            this.CUT.Margin = new System.Windows.Forms.Padding(6);
            this.CUT.Name = "CUT";
            this.CUT.Size = new System.Drawing.Size(150, 46);
            this.CUT.TabIndex = 2;
            this.CUT.Text = "剪下";
            this.CUT.UseVisualStyleBackColor = true;
            this.CUT.Click += new System.EventHandler(this.CUT_Click);
            // 
            // CREA
            // 
            this.CREA.Location = new System.Drawing.Point(262, 36);
            this.CREA.Margin = new System.Windows.Forms.Padding(6);
            this.CREA.Name = "CREA";
            this.CREA.Size = new System.Drawing.Size(150, 46);
            this.CREA.TabIndex = 1;
            this.CREA.Text = "產生";
            this.CREA.UseVisualStyleBackColor = true;
            this.CREA.Click += new System.EventHandler(this.CREA_Click);
            // 
            // CR_answer
            // 
            this.CR_answer.Location = new System.Drawing.Point(45, 49);
            this.CR_answer.Margin = new System.Windows.Forms.Padding(6);
            this.CR_answer.Name = "CR_answer";
            this.CR_answer.ReadOnly = true;
            this.CR_answer.Size = new System.Drawing.Size(196, 33);
            this.CR_answer.TabIndex = 0;
            this.CR_answer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // END
            // 
            this.END.Location = new System.Drawing.Point(234, 665);
            this.END.Margin = new System.Windows.Forms.Padding(6);
            this.END.Name = "END";
            this.END.Size = new System.Drawing.Size(150, 46);
            this.END.TabIndex = 7;
            this.END.Text = "結束";
            this.END.UseVisualStyleBackColor = true;
            this.END.Click += new System.EventHandler(this.END_Click);
            // 
            // three_chance
            // 
            this.three_chance.FormattingEnabled = true;
            this.three_chance.Items.AddRange(new object[] {
            "0-5  {其他}人民",
            "6 {取得國籍之外國人}人民",
            "7 {無戶籍國民}人民",
            "8 {港澳居民}人民",
            "9 {大陸地區}人民"});
            this.three_chance.Location = new System.Drawing.Point(285, 115);
            this.three_chance.Margin = new System.Windows.Forms.Padding(6);
            this.three_chance.Name = "three_chance";
            this.three_chance.Size = new System.Drawing.Size(238, 32);
            this.three_chance.TabIndex = 7;
            this.three_chance.Text = "請選擇第三碼類別";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(802, 726);
            this.Controls.Add(this.END);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ForeColor = System.Drawing.Color.Black;
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Form1";
            this.Text = "身分證驗證";
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox text_ans;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox input;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ComboBox WHERE;
        private System.Windows.Forms.RadioButton GIRL;
        private System.Windows.Forms.RadioButton BOY;
        private System.Windows.Forms.Button CUT;
        private System.Windows.Forms.Button CREA;
        private System.Windows.Forms.TextBox CR_answer;
        private System.Windows.Forms.Button END;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox three_chance;
    }
}

