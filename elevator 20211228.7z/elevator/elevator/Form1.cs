﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace elevator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }



        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            groupBox2.Enabled = true;
            groupBox3.Enabled = true;

            for (int i = 0; i <= 9; i++)
            {
                if (comboBox1.SelectedIndex == i)
                {
                    nowfloor1.Text = (i + 1).ToString();
                    nowfloor2.Text = (i + 1).ToString();

                }
            }
            switch (comboBox1.SelectedIndex)
            {
                case 0:
                    one_floor.Checked = true;
                    break;
                case 1:
                    two_floor.Checked = true;
                    break;
                case 2:
                    three_floor.Checked = true;
                    break;
                case 3:
                    four_floor.Checked = true;
                    break;
                case 4:
                    five_floor.Checked = true;
                    break;
                case 5:
                    six_floor.Checked = true;
                    break;
                case 6:
                    seven_floor.Checked = true;
                    break;
                case 7:
                    eight_floor.Checked = true;
                    break;
                case 8:
                    nine_floor.Checked = true;
                    break;
                case 9:
                    ten_floor.Checked = true;
                    break;
            }
        }

        private void one_chance_Click(object sender, EventArgs e)
        {
            if (ele_up.Checked || ele_down.Checked)
            {
                if (one_floor.Checked != true) one_chance.Checked = !one_chance.Checked;
            }
            else return;
        }

        private void two_chance_Click(object sender, EventArgs e)
        {

            if (ele_up.Checked || ele_down.Checked)
            {
                if (two_floor.Checked != true) two_chance.Checked = !two_chance.Checked;
            }
            else return;
        }

        private void three_chance_Click(object sender, EventArgs e)
        {

            if (ele_up.Checked || ele_down.Checked)
            {
                if (three_floor.Checked != true) three_chance.Checked = !three_chance.Checked;
            }
            else return;
        }

        private void four_chance_Click(object sender, EventArgs e)
        {

            if (ele_up.Checked || ele_down.Checked)
            {
                if (four_floor.Checked != true) four_chance.Checked = !four_chance.Checked;
            }
            else return;
        }

        private void five_chance_Click(object sender, EventArgs e)
        {

            if (ele_up.Checked || ele_down.Checked)
            {
                if (five_floor.Checked != true) five_chance.Checked = !five_chance.Checked;
            }
            else return;
        }

        private void six_chance_Click(object sender, EventArgs e)
        {

            if (ele_up.Checked || ele_down.Checked)
            {
                if (six_floor.Checked != true) six_chance.Checked = !six_chance.Checked;
            }
            else return;
        }

        private void seven_chance_Click(object sender, EventArgs e)
        {

            if (ele_up.Checked || ele_down.Checked)
            {
                if (seven_floor.Checked != true) seven_chance.Checked = !seven_chance.Checked;
            }
            else return;
        }

        private void eight_chance_Click(object sender, EventArgs e)
        {

            if (ele_up.Checked || ele_down.Checked)
            {
                if (eight_floor.Checked != true) eight_chance.Checked = !eight_chance.Checked;
            }
            else return;
        }

        private void nine_chance_Click(object sender, EventArgs e)
        {

            if (ele_up.Checked || ele_down.Checked)
            {
                if (nine_floor.Checked != true) nine_chance.Checked = !nine_chance.Checked;
            }
            else return;
        }

        private void ten_chance_Click(object sender, EventArgs e)
        {

            if (ele_up.Checked || ele_down.Checked)
            {
                if (ten_floor.Checked != true) ten_chance.Checked = !ten_chance.Checked;
            }
            else return;
        }

        private void ele_up_Click(object sender, EventArgs e)
        {
            if (ele_down.Checked) return;
            else ele_up.Checked = true;
        }

        private void ele_down_Click(object sender, EventArgs e)
        {
            if (ele_up.Checked) return;
            else ele_down.Checked = true;
        }

        private void close_door_Click(object sender, EventArgs e)
        {
            if (ele_down.Checked || ele_up.Checked)
            {
                ationele();
            }
            else close_door.Checked = false;
        }
        private void ationele()
        {

            if (ele_up.Checked)
            {
                updown(true);
            }
            else if (ele_down.Checked)
            {

                updown(false);
            }
            open_door.Checked = true; ;
            ele_up.Checked = false;
            ele_down.Checked = false;
        }
        private void elemove(int x)
        {
            System.Threading.Thread.Sleep(500);
            switch (x)
            {
                case 1:
                    //comboBox1.SelectedIndex = 0;
                    nowfloor1.Text = "1";
                    nowfloor2.Text = "1";
                    colorec();
                    textBox10.BackColor = Color.Blue;
                    one_floor.Checked = true;
                    if (one_chance.Checked)
                    {
                        MessageBox.Show("一樓到了", "樓層提示");
                        one_chance.Checked = false;
                    }
                    break;
                case 2:
                    //comboBox1.SelectedIndex = 1;
                    nowfloor1.Text = "2";
                    nowfloor2.Text = "2";
                    colorec();
                    textBox9.BackColor = Color.Blue;
                    two_floor.Checked = true;
                    if (two_chance.Checked)
                    {
                        MessageBox.Show("二樓到了", "樓層提示");
                        two_chance.Checked = false;
                    }
                    break;
                case 3:
                    //comboBox1.SelectedIndex = 2;
                    nowfloor1.Text = "3";
                    nowfloor2.Text = "3";
                    colorec();
                    textBox8.BackColor = Color.Blue;
                    three_floor.Checked = true;
                    if (three_chance.Checked)
                    {
                        MessageBox.Show("三樓到了", "樓層提示");
                        three_chance.Checked = false;
                    }
                    break;
                case 4:
                    //comboBox1.SelectedIndex = 3;
                    nowfloor1.Text = "4";
                    nowfloor2.Text = "4";
                    colorec();
                    textBox7.BackColor = Color.Blue;
                    four_floor.Checked = true;
                    if (four_chance.Checked)
                    {
                        MessageBox.Show("四樓到了", "樓層提示");
                        four_chance.Checked = false;
                    }
                    break;
                case 5:
                    //comboBox1.SelectedIndex = 4;
                    nowfloor1.Text = "5";
                    nowfloor2.Text = "5";
                    colorec();
                    textBox6.BackColor = Color.Blue;
                    five_floor.Checked = true;
                    if (five_chance.Checked)
                    {
                        MessageBox.Show("五樓到了", "樓層提示");
                        five_chance.Checked = false;
                    }
                    break;
                case 6:
                    //comboBox1.SelectedIndex = 5;
                    nowfloor1.Text = "6";
                    nowfloor2.Text = "6";
                    colorec();
                    textBox5.BackColor = Color.Blue;
                    six_floor.Checked = true;
                    if (six_chance.Checked)
                    {
                        MessageBox.Show("六樓到了", "樓層提示");
                        six_chance.Checked = false;
                    }
                    break;
                case 7:
                    //comboBox1.SelectedIndex = 6;
                    nowfloor1.Text = "7";
                    nowfloor2.Text = "7";
                    colorec();
                    textBox4.BackColor = Color.Blue;
                    seven_floor.Checked = true;
                    if (seven_chance.Checked)
                    {
                        MessageBox.Show("七樓到了", "樓層提示");
                        seven_chance.Checked = false;
                    }
                    break;
                case 8:
                    //comboBox1.SelectedIndex = 7;
                    nowfloor1.Text = "8";
                    nowfloor2.Text = "8";
                    colorec();
                    textBox3.BackColor = Color.Blue;
                    eight_floor.Checked = true;
                    if (eight_chance.Checked)
                    {
                        MessageBox.Show("八樓到了", "樓層提示");
                        eight_chance.Checked = false;
                    }
                    break;
                case 9:
                    //comboBox1.SelectedIndex = 8;
                    nowfloor1.Text = "9";
                    nowfloor2.Text = "9";
                    colorec();
                    textBox2.BackColor = Color.Blue;
                    nine_floor.Checked = true;
                    if (nine_chance.Checked)
                    {
                        MessageBox.Show("九樓到了", "樓層提示");
                        nine_chance.Checked = false;
                    }
                    break;
                case 10:
                    //comboBox1.SelectedIndex = 9;
                    nowfloor1.Text = "10";
                    nowfloor2.Text = "10";
                    colorec();
                    textBox1.BackColor = Color.Blue;
                    ten_floor.Checked = true;
                    if (ten_chance.Checked)
                    {
                        MessageBox.Show("十樓到了", "樓層提示");
                        ten_chance.Checked = false;
                    }
                    break;
                default:
                    break;
            }
        }

        private void updown(bool now)
        {
            int x = comboBox1.SelectedIndex + 1;
            while (one_chance.Checked || two_chance.Checked || three_chance.Checked
                || four_chance.Checked || five_chance.Checked || six_chance.Checked
                || seven_chance.Checked || eight_chance.Checked || nine_chance.Checked
                || ten_chance.Checked)
            {
                MessageBox.Show("樓層抵達", "樓層提示", MessageBoxButtons.OK);

                if (now)//上
                {
                    nowele.Text = "電梯上升";
                    ele_up.Checked = true;
                    ele_down.Checked = false;
                    if (x > 10)
                    {
                        now = false;
                        continue;
                    }
                    //MessageBox.Show(x.ToString());
                    elemove(x);
                    x++;
                }
                else //下
                {
                    nowele.Text = "電梯下降";
                    ele_down.Checked = true;
                    ele_up.Checked = false;
                    if (x < 1)
                    {
                        now = true;
                        continue;
                    }
                    //MessageBox.Show(x.ToString());
                    elemove(x);
                    x--;
                }

            }
            nowele.Text = "電梯暫停";
        }

        private void colorec()
        {
            textBox1.BackColor = Color.White;
            textBox2.BackColor = Color.White;
            textBox3.BackColor = Color.White;
            textBox4.BackColor = Color.White;
            textBox5.BackColor = Color.White;
            textBox6.BackColor = Color.White;
            textBox7.BackColor = Color.White;
            textBox8.BackColor = Color.White;
            textBox9.BackColor = Color.White;
            textBox10.BackColor = Color.White;
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }
    }
}

       
