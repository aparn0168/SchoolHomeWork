﻿
namespace elevator
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ten_floor = new System.Windows.Forms.RadioButton();
            this.nine_floor = new System.Windows.Forms.RadioButton();
            this.three_floor = new System.Windows.Forms.RadioButton();
            this.four_floor = new System.Windows.Forms.RadioButton();
            this.six_floor = new System.Windows.Forms.RadioButton();
            this.seven_floor = new System.Windows.Forms.RadioButton();
            this.eight_floor = new System.Windows.Forms.RadioButton();
            this.five_floor = new System.Windows.Forms.RadioButton();
            this.two_floor = new System.Windows.Forms.RadioButton();
            this.one_floor = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.nowfloor2 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.ele_down = new System.Windows.Forms.RadioButton();
            this.ele_up = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.close_door = new System.Windows.Forms.RadioButton();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.ten_chance = new System.Windows.Forms.RadioButton();
            this.nine_chance = new System.Windows.Forms.RadioButton();
            this.three_chance = new System.Windows.Forms.RadioButton();
            this.four_chance = new System.Windows.Forms.RadioButton();
            this.six_chance = new System.Windows.Forms.RadioButton();
            this.seven_chance = new System.Windows.Forms.RadioButton();
            this.eight_chance = new System.Windows.Forms.RadioButton();
            this.five_chance = new System.Windows.Forms.RadioButton();
            this.two_chance = new System.Windows.Forms.RadioButton();
            this.one_chance = new System.Windows.Forms.RadioButton();
            this.open_door = new System.Windows.Forms.RadioButton();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.nowfloor1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.nowele = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.groupBox1.Controls.Add(this.ten_floor);
            this.groupBox1.Controls.Add(this.nine_floor);
            this.groupBox1.Controls.Add(this.three_floor);
            this.groupBox1.Controls.Add(this.four_floor);
            this.groupBox1.Controls.Add(this.six_floor);
            this.groupBox1.Controls.Add(this.seven_floor);
            this.groupBox1.Controls.Add(this.eight_floor);
            this.groupBox1.Controls.Add(this.five_floor);
            this.groupBox1.Controls.Add(this.two_floor);
            this.groupBox1.Controls.Add(this.one_floor);
            this.groupBox1.Enabled = false;
            this.groupBox1.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox1.ForeColor = System.Drawing.Color.Black;
            this.groupBox1.Location = new System.Drawing.Point(51, 10);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(737, 97);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "目前電梯樓層";
            // 
            // ten_floor
            // 
            this.ten_floor.AutoSize = true;
            this.ten_floor.BackColor = System.Drawing.Color.Transparent;
            this.ten_floor.Location = new System.Drawing.Point(634, 55);
            this.ten_floor.Margin = new System.Windows.Forms.Padding(2);
            this.ten_floor.Name = "ten_floor";
            this.ten_floor.Size = new System.Drawing.Size(84, 35);
            this.ten_floor.TabIndex = 9;
            this.ten_floor.Text = "10樓";
            this.ten_floor.UseVisualStyleBackColor = false;
            // 
            // nine_floor
            // 
            this.nine_floor.AutoSize = true;
            this.nine_floor.BackColor = System.Drawing.Color.Transparent;
            this.nine_floor.Location = new System.Drawing.Point(566, 55);
            this.nine_floor.Margin = new System.Windows.Forms.Padding(2);
            this.nine_floor.Name = "nine_floor";
            this.nine_floor.Size = new System.Drawing.Size(70, 35);
            this.nine_floor.TabIndex = 8;
            this.nine_floor.Text = "9樓";
            this.nine_floor.UseVisualStyleBackColor = false;
            // 
            // three_floor
            // 
            this.three_floor.AutoSize = true;
            this.three_floor.BackColor = System.Drawing.Color.Transparent;
            this.three_floor.Location = new System.Drawing.Point(142, 55);
            this.three_floor.Margin = new System.Windows.Forms.Padding(2);
            this.three_floor.Name = "three_floor";
            this.three_floor.Size = new System.Drawing.Size(70, 35);
            this.three_floor.TabIndex = 7;
            this.three_floor.Text = "3樓";
            this.three_floor.UseVisualStyleBackColor = false;
            // 
            // four_floor
            // 
            this.four_floor.AutoSize = true;
            this.four_floor.BackColor = System.Drawing.Color.Transparent;
            this.four_floor.Location = new System.Drawing.Point(212, 55);
            this.four_floor.Margin = new System.Windows.Forms.Padding(2);
            this.four_floor.Name = "four_floor";
            this.four_floor.Size = new System.Drawing.Size(70, 35);
            this.four_floor.TabIndex = 6;
            this.four_floor.Text = "4樓";
            this.four_floor.UseVisualStyleBackColor = false;
            // 
            // six_floor
            // 
            this.six_floor.AutoSize = true;
            this.six_floor.BackColor = System.Drawing.Color.Transparent;
            this.six_floor.Location = new System.Drawing.Point(358, 55);
            this.six_floor.Margin = new System.Windows.Forms.Padding(2);
            this.six_floor.Name = "six_floor";
            this.six_floor.Size = new System.Drawing.Size(70, 35);
            this.six_floor.TabIndex = 5;
            this.six_floor.Text = "6樓";
            this.six_floor.UseVisualStyleBackColor = false;
            // 
            // seven_floor
            // 
            this.seven_floor.AutoSize = true;
            this.seven_floor.BackColor = System.Drawing.Color.Transparent;
            this.seven_floor.Location = new System.Drawing.Point(428, 55);
            this.seven_floor.Margin = new System.Windows.Forms.Padding(2);
            this.seven_floor.Name = "seven_floor";
            this.seven_floor.Size = new System.Drawing.Size(70, 35);
            this.seven_floor.TabIndex = 4;
            this.seven_floor.Text = "7樓";
            this.seven_floor.UseVisualStyleBackColor = false;
            // 
            // eight_floor
            // 
            this.eight_floor.AutoSize = true;
            this.eight_floor.BackColor = System.Drawing.Color.Transparent;
            this.eight_floor.Location = new System.Drawing.Point(496, 55);
            this.eight_floor.Margin = new System.Windows.Forms.Padding(2);
            this.eight_floor.Name = "eight_floor";
            this.eight_floor.Size = new System.Drawing.Size(70, 35);
            this.eight_floor.TabIndex = 3;
            this.eight_floor.Text = "8樓";
            this.eight_floor.UseVisualStyleBackColor = false;
            // 
            // five_floor
            // 
            this.five_floor.AutoSize = true;
            this.five_floor.BackColor = System.Drawing.Color.Transparent;
            this.five_floor.Location = new System.Drawing.Point(290, 55);
            this.five_floor.Margin = new System.Windows.Forms.Padding(2);
            this.five_floor.Name = "five_floor";
            this.five_floor.Size = new System.Drawing.Size(70, 35);
            this.five_floor.TabIndex = 2;
            this.five_floor.Text = "5樓";
            this.five_floor.UseVisualStyleBackColor = false;
            // 
            // two_floor
            // 
            this.two_floor.AutoSize = true;
            this.two_floor.BackColor = System.Drawing.Color.Transparent;
            this.two_floor.Location = new System.Drawing.Point(74, 55);
            this.two_floor.Margin = new System.Windows.Forms.Padding(2);
            this.two_floor.Name = "two_floor";
            this.two_floor.Size = new System.Drawing.Size(70, 35);
            this.two_floor.TabIndex = 1;
            this.two_floor.Text = "2樓";
            this.two_floor.UseVisualStyleBackColor = false;
            // 
            // one_floor
            // 
            this.one_floor.AutoSize = true;
            this.one_floor.BackColor = System.Drawing.Color.Transparent;
            this.one_floor.Checked = true;
            this.one_floor.Location = new System.Drawing.Point(4, 55);
            this.one_floor.Margin = new System.Windows.Forms.Padding(2);
            this.one_floor.Name = "one_floor";
            this.one_floor.Size = new System.Drawing.Size(70, 35);
            this.one_floor.TabIndex = 0;
            this.one_floor.TabStop = true;
            this.one_floor.Text = "1樓";
            this.one_floor.UseVisualStyleBackColor = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.nowfloor2);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.ele_down);
            this.groupBox2.Controls.Add(this.ele_up);
            this.groupBox2.Enabled = false;
            this.groupBox2.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox2.Location = new System.Drawing.Point(56, 153);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox2.Size = new System.Drawing.Size(189, 313);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "電梯外部控制";
            // 
            // nowfloor2
            // 
            this.nowfloor2.AutoSize = true;
            this.nowfloor2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.nowfloor2.ForeColor = System.Drawing.Color.Red;
            this.nowfloor2.Location = new System.Drawing.Point(79, 90);
            this.nowfloor2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.nowfloor2.Name = "nowfloor2";
            this.nowfloor2.Size = new System.Drawing.Size(21, 24);
            this.nowfloor2.TabIndex = 5;
            this.nowfloor2.Text = "1";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(51, 50);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(86, 24);
            this.label9.TabIndex = 4;
            this.label9.Text = "目前樓層";
            // 
            // ele_down
            // 
            this.ele_down.AutoCheck = false;
            this.ele_down.AutoSize = true;
            this.ele_down.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ele_down.ForeColor = System.Drawing.Color.Black;
            this.ele_down.Location = new System.Drawing.Point(55, 208);
            this.ele_down.Margin = new System.Windows.Forms.Padding(2);
            this.ele_down.Name = "ele_down";
            this.ele_down.Size = new System.Drawing.Size(95, 28);
            this.ele_down.TabIndex = 2;
            this.ele_down.TabStop = true;
            this.ele_down.Text = "DOWN";
            this.ele_down.UseVisualStyleBackColor = false;
            this.ele_down.Click += new System.EventHandler(this.ele_down_Click);
            // 
            // ele_up
            // 
            this.ele_up.AutoCheck = false;
            this.ele_up.AutoSize = true;
            this.ele_up.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ele_up.ForeColor = System.Drawing.Color.Black;
            this.ele_up.Location = new System.Drawing.Point(69, 142);
            this.ele_up.Margin = new System.Windows.Forms.Padding(2);
            this.ele_up.Name = "ele_up";
            this.ele_up.Size = new System.Drawing.Size(54, 28);
            this.ele_up.TabIndex = 1;
            this.ele_up.TabStop = true;
            this.ele_up.Text = "UP";
            this.ele_up.UseVisualStyleBackColor = false;
            this.ele_up.Click += new System.EventHandler(this.ele_up_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.close_door);
            this.groupBox3.Controls.Add(this.groupBox5);
            this.groupBox3.Controls.Add(this.open_door);
            this.groupBox3.Enabled = false;
            this.groupBox3.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox3.Location = new System.Drawing.Point(310, 153);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox3.Size = new System.Drawing.Size(200, 365);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "電梯內部控制";
            // 
            // close_door
            // 
            this.close_door.AutoSize = true;
            this.close_door.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.close_door.ForeColor = System.Drawing.Color.Black;
            this.close_door.Location = new System.Drawing.Point(109, 318);
            this.close_door.Margin = new System.Windows.Forms.Padding(2);
            this.close_door.Name = "close_door";
            this.close_door.Size = new System.Drawing.Size(66, 28);
            this.close_door.TabIndex = 1;
            this.close_door.TabStop = true;
            this.close_door.Text = "關門";
            this.close_door.UseVisualStyleBackColor = false;
            this.close_door.Click += new System.EventHandler(this.close_door_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.groupBox5.Controls.Add(this.groupBox6);
            this.groupBox5.Controls.Add(this.ten_chance);
            this.groupBox5.Controls.Add(this.nine_chance);
            this.groupBox5.Controls.Add(this.three_chance);
            this.groupBox5.Controls.Add(this.four_chance);
            this.groupBox5.Controls.Add(this.six_chance);
            this.groupBox5.Controls.Add(this.seven_chance);
            this.groupBox5.Controls.Add(this.eight_chance);
            this.groupBox5.Controls.Add(this.five_chance);
            this.groupBox5.Controls.Add(this.two_chance);
            this.groupBox5.Controls.Add(this.one_chance);
            this.groupBox5.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox5.ForeColor = System.Drawing.Color.Black;
            this.groupBox5.Location = new System.Drawing.Point(30, 38);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox5.Size = new System.Drawing.Size(141, 250);
            this.groupBox5.TabIndex = 1;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "請選擇樓層";
            // 
            // ten_chance
            // 
            this.ten_chance.AutoCheck = false;
            this.ten_chance.AutoSize = true;
            this.ten_chance.BackColor = System.Drawing.Color.Transparent;
            this.ten_chance.Location = new System.Drawing.Point(74, 209);
            this.ten_chance.Margin = new System.Windows.Forms.Padding(2);
            this.ten_chance.Name = "ten_chance";
            this.ten_chance.Size = new System.Drawing.Size(64, 25);
            this.ten_chance.TabIndex = 9;
            this.ten_chance.Text = "10樓";
            this.ten_chance.UseVisualStyleBackColor = false;
            this.ten_chance.Click += new System.EventHandler(this.ten_chance_Click);
            // 
            // nine_chance
            // 
            this.nine_chance.AutoCheck = false;
            this.nine_chance.AutoSize = true;
            this.nine_chance.BackColor = System.Drawing.Color.Transparent;
            this.nine_chance.Location = new System.Drawing.Point(74, 173);
            this.nine_chance.Margin = new System.Windows.Forms.Padding(2);
            this.nine_chance.Name = "nine_chance";
            this.nine_chance.Size = new System.Drawing.Size(54, 25);
            this.nine_chance.TabIndex = 8;
            this.nine_chance.Text = "9樓";
            this.nine_chance.UseVisualStyleBackColor = false;
            this.nine_chance.Click += new System.EventHandler(this.nine_chance_Click);
            // 
            // three_chance
            // 
            this.three_chance.AutoCheck = false;
            this.three_chance.AutoSize = true;
            this.three_chance.BackColor = System.Drawing.Color.Transparent;
            this.three_chance.Location = new System.Drawing.Point(4, 132);
            this.three_chance.Margin = new System.Windows.Forms.Padding(2);
            this.three_chance.Name = "three_chance";
            this.three_chance.Size = new System.Drawing.Size(54, 25);
            this.three_chance.TabIndex = 7;
            this.three_chance.Text = "3樓";
            this.three_chance.UseVisualStyleBackColor = false;
            this.three_chance.Click += new System.EventHandler(this.three_chance_Click);
            // 
            // four_chance
            // 
            this.four_chance.AutoCheck = false;
            this.four_chance.AutoSize = true;
            this.four_chance.BackColor = System.Drawing.Color.Transparent;
            this.four_chance.Location = new System.Drawing.Point(4, 170);
            this.four_chance.Margin = new System.Windows.Forms.Padding(2);
            this.four_chance.Name = "four_chance";
            this.four_chance.Size = new System.Drawing.Size(54, 25);
            this.four_chance.TabIndex = 6;
            this.four_chance.Text = "4樓";
            this.four_chance.UseVisualStyleBackColor = false;
            this.four_chance.Click += new System.EventHandler(this.four_chance_Click);
            // 
            // six_chance
            // 
            this.six_chance.AutoCheck = false;
            this.six_chance.AutoSize = true;
            this.six_chance.BackColor = System.Drawing.Color.Transparent;
            this.six_chance.Location = new System.Drawing.Point(74, 55);
            this.six_chance.Margin = new System.Windows.Forms.Padding(2);
            this.six_chance.Name = "six_chance";
            this.six_chance.Size = new System.Drawing.Size(54, 25);
            this.six_chance.TabIndex = 5;
            this.six_chance.Text = "6樓";
            this.six_chance.UseVisualStyleBackColor = false;
            this.six_chance.Click += new System.EventHandler(this.six_chance_Click);
            // 
            // seven_chance
            // 
            this.seven_chance.AutoCheck = false;
            this.seven_chance.AutoSize = true;
            this.seven_chance.BackColor = System.Drawing.Color.Transparent;
            this.seven_chance.Location = new System.Drawing.Point(74, 94);
            this.seven_chance.Margin = new System.Windows.Forms.Padding(2);
            this.seven_chance.Name = "seven_chance";
            this.seven_chance.Size = new System.Drawing.Size(54, 25);
            this.seven_chance.TabIndex = 4;
            this.seven_chance.Text = "7樓";
            this.seven_chance.UseVisualStyleBackColor = false;
            this.seven_chance.Click += new System.EventHandler(this.seven_chance_Click);
            // 
            // eight_chance
            // 
            this.eight_chance.AutoCheck = false;
            this.eight_chance.AutoSize = true;
            this.eight_chance.BackColor = System.Drawing.Color.Transparent;
            this.eight_chance.Location = new System.Drawing.Point(74, 134);
            this.eight_chance.Margin = new System.Windows.Forms.Padding(2);
            this.eight_chance.Name = "eight_chance";
            this.eight_chance.Size = new System.Drawing.Size(54, 25);
            this.eight_chance.TabIndex = 3;
            this.eight_chance.Text = "8樓";
            this.eight_chance.UseVisualStyleBackColor = false;
            this.eight_chance.Click += new System.EventHandler(this.eight_chance_Click);
            // 
            // five_chance
            // 
            this.five_chance.AutoCheck = false;
            this.five_chance.AutoSize = true;
            this.five_chance.BackColor = System.Drawing.Color.Transparent;
            this.five_chance.Location = new System.Drawing.Point(4, 209);
            this.five_chance.Margin = new System.Windows.Forms.Padding(2);
            this.five_chance.Name = "five_chance";
            this.five_chance.Size = new System.Drawing.Size(54, 25);
            this.five_chance.TabIndex = 2;
            this.five_chance.Text = "5樓";
            this.five_chance.UseVisualStyleBackColor = false;
            this.five_chance.Click += new System.EventHandler(this.five_chance_Click);
            // 
            // two_chance
            // 
            this.two_chance.AutoCheck = false;
            this.two_chance.AutoSize = true;
            this.two_chance.BackColor = System.Drawing.Color.Transparent;
            this.two_chance.Location = new System.Drawing.Point(4, 94);
            this.two_chance.Margin = new System.Windows.Forms.Padding(2);
            this.two_chance.Name = "two_chance";
            this.two_chance.Size = new System.Drawing.Size(54, 25);
            this.two_chance.TabIndex = 1;
            this.two_chance.Text = "2樓";
            this.two_chance.UseVisualStyleBackColor = false;
            this.two_chance.Click += new System.EventHandler(this.two_chance_Click);
            // 
            // one_chance
            // 
            this.one_chance.AutoCheck = false;
            this.one_chance.AutoSize = true;
            this.one_chance.BackColor = System.Drawing.Color.Transparent;
            this.one_chance.Location = new System.Drawing.Point(4, 55);
            this.one_chance.Margin = new System.Windows.Forms.Padding(2);
            this.one_chance.Name = "one_chance";
            this.one_chance.Size = new System.Drawing.Size(54, 25);
            this.one_chance.TabIndex = 0;
            this.one_chance.TabStop = true;
            this.one_chance.Text = "1樓";
            this.one_chance.UseVisualStyleBackColor = false;
            this.one_chance.Click += new System.EventHandler(this.one_chance_Click);
            // 
            // open_door
            // 
            this.open_door.AutoSize = true;
            this.open_door.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.open_door.Enabled = false;
            this.open_door.ForeColor = System.Drawing.Color.Black;
            this.open_door.Location = new System.Drawing.Point(30, 318);
            this.open_door.Margin = new System.Windows.Forms.Padding(2);
            this.open_door.Name = "open_door";
            this.open_door.Size = new System.Drawing.Size(66, 28);
            this.open_door.TabIndex = 0;
            this.open_door.TabStop = true;
            this.open_door.Text = "開門";
            this.open_door.UseVisualStyleBackColor = false;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.nowfloor1);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Controls.Add(this.comboBox1);
            this.groupBox4.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox4.Location = new System.Drawing.Point(608, 153);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox4.Size = new System.Drawing.Size(189, 210);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "電梯設定";
            // 
            // nowfloor1
            // 
            this.nowfloor1.AutoSize = true;
            this.nowfloor1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.nowfloor1.ForeColor = System.Drawing.Color.Red;
            this.nowfloor1.Location = new System.Drawing.Point(73, 170);
            this.nowfloor1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.nowfloor1.Name = "nowfloor1";
            this.nowfloor1.Size = new System.Drawing.Size(21, 24);
            this.nowfloor1.TabIndex = 3;
            this.nowfloor1.Text = "1";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(45, 130);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 24);
            this.label7.TabIndex = 2;
            this.label7.Text = "目前樓層";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(45, 60);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "設定樓層";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "1樓",
            "2樓",
            "3樓",
            "4樓",
            "5樓",
            "6樓",
            "7樓",
            "8樓",
            "9樓",
            "10樓"});
            this.comboBox1.Location = new System.Drawing.Point(26, 87);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(2);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(137, 31);
            this.comboBox1.TabIndex = 0;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(22, 34);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 24);
            this.label3.TabIndex = 5;
            this.label3.Text = "1.選擇樓層";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(21, 69);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 24);
            this.label4.TabIndex = 6;
            this.label4.Text = "2.選擇上下";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(21, 104);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(159, 24);
            this.label5.TabIndex = 7;
            this.label5.Text = "3.選擇要去的樓層";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(22, 139);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 24);
            this.label6.TabIndex = 8;
            this.label6.Text = "4.關門";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.textBox10);
            this.panel2.Controls.Add(this.textBox9);
            this.panel2.Controls.Add(this.textBox8);
            this.panel2.Controls.Add(this.textBox7);
            this.panel2.Controls.Add(this.textBox6);
            this.panel2.Controls.Add(this.textBox5);
            this.panel2.Controls.Add(this.textBox4);
            this.panel2.Controls.Add(this.textBox3);
            this.panel2.Controls.Add(this.textBox2);
            this.panel2.Controls.Add(this.textBox1);
            this.panel2.Enabled = false;
            this.panel2.Location = new System.Drawing.Point(827, 78);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(148, 492);
            this.panel2.TabIndex = 9;
            // 
            // textBox10
            // 
            this.textBox10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.textBox10.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.textBox10.Location = new System.Drawing.Point(20, 447);
            this.textBox10.Margin = new System.Windows.Forms.Padding(2);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(115, 32);
            this.textBox10.TabIndex = 10;
            this.textBox10.Text = "1F";
            this.textBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox9
            // 
            this.textBox9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.textBox9.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.textBox9.Location = new System.Drawing.Point(20, 406);
            this.textBox9.Margin = new System.Windows.Forms.Padding(2);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(115, 32);
            this.textBox9.TabIndex = 9;
            this.textBox9.Text = "2F";
            this.textBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox8
            // 
            this.textBox8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.textBox8.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.textBox8.Location = new System.Drawing.Point(20, 358);
            this.textBox8.Margin = new System.Windows.Forms.Padding(2);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(115, 32);
            this.textBox8.TabIndex = 8;
            this.textBox8.Text = "3F";
            this.textBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.textBox7.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.textBox7.Location = new System.Drawing.Point(20, 314);
            this.textBox7.Margin = new System.Windows.Forms.Padding(2);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(115, 32);
            this.textBox7.TabIndex = 7;
            this.textBox7.Text = "4F";
            this.textBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.textBox6.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.textBox6.Location = new System.Drawing.Point(20, 265);
            this.textBox6.Margin = new System.Windows.Forms.Padding(2);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(115, 32);
            this.textBox6.TabIndex = 6;
            this.textBox6.Text = "5F";
            this.textBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.textBox5.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.textBox5.Location = new System.Drawing.Point(20, 214);
            this.textBox5.Margin = new System.Windows.Forms.Padding(2);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(115, 32);
            this.textBox5.TabIndex = 5;
            this.textBox5.Text = "6F";
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.textBox4.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.textBox4.Location = new System.Drawing.Point(20, 166);
            this.textBox4.Margin = new System.Windows.Forms.Padding(2);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(115, 32);
            this.textBox4.TabIndex = 4;
            this.textBox4.Text = "7F";
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.textBox3.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.textBox3.Location = new System.Drawing.Point(20, 117);
            this.textBox3.Margin = new System.Windows.Forms.Padding(2);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(115, 32);
            this.textBox3.TabIndex = 3;
            this.textBox3.Text = "8F";
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.textBox2.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.textBox2.Location = new System.Drawing.Point(20, 71);
            this.textBox2.Margin = new System.Windows.Forms.Padding(2);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(115, 32);
            this.textBox2.TabIndex = 2;
            this.textBox2.Text = "9F";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.textBox1.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.textBox1.Location = new System.Drawing.Point(20, 27);
            this.textBox1.Margin = new System.Windows.Forms.Padding(2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(115, 32);
            this.textBox1.TabIndex = 1;
            this.textBox1.Text = "10F";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nowele
            // 
            this.nowele.AutoSize = true;
            this.nowele.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.nowele.Font = new System.Drawing.Font("微軟正黑體", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.nowele.Location = new System.Drawing.Point(826, 30);
            this.nowele.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.nowele.Name = "nowele";
            this.nowele.Size = new System.Drawing.Size(160, 45);
            this.nowele.TabIndex = 0;
            this.nowele.Text = "電梯暫停";
            // 
            // groupBox6
            // 
            this.groupBox6.Location = new System.Drawing.Point(139, 12);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(200, 186);
            this.groupBox6.TabIndex = 10;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "groupBox6";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label3);
            this.groupBox7.Controls.Add(this.label6);
            this.groupBox7.Controls.Add(this.label4);
            this.groupBox7.Controls.Add(this.label5);
            this.groupBox7.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox7.Location = new System.Drawing.Point(608, 367);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox7.Size = new System.Drawing.Size(189, 187);
            this.groupBox7.TabIndex = 10;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "使用步驟";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Olive;
            this.ClientSize = new System.Drawing.Size(1003, 581);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.nowele);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton ten_floor;
        private System.Windows.Forms.RadioButton nine_floor;
        private System.Windows.Forms.RadioButton three_floor;
        private System.Windows.Forms.RadioButton four_floor;
        private System.Windows.Forms.RadioButton six_floor;
        private System.Windows.Forms.RadioButton seven_floor;
        private System.Windows.Forms.RadioButton eight_floor;
        private System.Windows.Forms.RadioButton five_floor;
        private System.Windows.Forms.RadioButton two_floor;
        private System.Windows.Forms.RadioButton one_floor;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton ele_down;
        private System.Windows.Forms.RadioButton ele_up;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton close_door;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.RadioButton ten_chance;
        private System.Windows.Forms.RadioButton nine_chance;
        private System.Windows.Forms.RadioButton three_chance;
        private System.Windows.Forms.RadioButton four_chance;
        private System.Windows.Forms.RadioButton six_chance;
        private System.Windows.Forms.RadioButton seven_chance;
        private System.Windows.Forms.RadioButton eight_chance;
        private System.Windows.Forms.RadioButton five_chance;
        private System.Windows.Forms.RadioButton two_chance;
        private System.Windows.Forms.RadioButton one_chance;
        private System.Windows.Forms.RadioButton open_door;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label nowfloor2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label nowfloor1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label nowele;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox7;
    }
}

