﻿
namespace elevator
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ten_floor = new System.Windows.Forms.RadioButton();
            this.nine_floor = new System.Windows.Forms.RadioButton();
            this.three_floor = new System.Windows.Forms.RadioButton();
            this.four_floor = new System.Windows.Forms.RadioButton();
            this.six_floor = new System.Windows.Forms.RadioButton();
            this.seven_floor = new System.Windows.Forms.RadioButton();
            this.eight_floor = new System.Windows.Forms.RadioButton();
            this.five_floor = new System.Windows.Forms.RadioButton();
            this.two_floor = new System.Windows.Forms.RadioButton();
            this.one_floor = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.down = new System.Windows.Forms.Button();
            this.up = new System.Windows.Forms.Button();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.close_door = new System.Windows.Forms.RadioButton();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.ten_chance = new System.Windows.Forms.RadioButton();
            this.nine_chance = new System.Windows.Forms.RadioButton();
            this.three_chance = new System.Windows.Forms.RadioButton();
            this.four_chance = new System.Windows.Forms.RadioButton();
            this.six_chance = new System.Windows.Forms.RadioButton();
            this.seven_chance = new System.Windows.Forms.RadioButton();
            this.eight_chance = new System.Windows.Forms.RadioButton();
            this.five_chance = new System.Windows.Forms.RadioButton();
            this.two_chance = new System.Windows.Forms.RadioButton();
            this.one_chance = new System.Windows.Forms.RadioButton();
            this.open_door = new System.Windows.Forms.RadioButton();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.groupBox1.Controls.Add(this.ten_floor);
            this.groupBox1.Controls.Add(this.nine_floor);
            this.groupBox1.Controls.Add(this.three_floor);
            this.groupBox1.Controls.Add(this.four_floor);
            this.groupBox1.Controls.Add(this.six_floor);
            this.groupBox1.Controls.Add(this.seven_floor);
            this.groupBox1.Controls.Add(this.eight_floor);
            this.groupBox1.Controls.Add(this.five_floor);
            this.groupBox1.Controls.Add(this.two_floor);
            this.groupBox1.Controls.Add(this.one_floor);
            this.groupBox1.Enabled = false;
            this.groupBox1.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox1.ForeColor = System.Drawing.Color.Black;
            this.groupBox1.Location = new System.Drawing.Point(68, 12);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Size = new System.Drawing.Size(983, 121);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "目前電梯樓層";
            // 
            // ten_floor
            // 
            this.ten_floor.AutoSize = true;
            this.ten_floor.BackColor = System.Drawing.Color.Transparent;
            this.ten_floor.Location = new System.Drawing.Point(845, 69);
            this.ten_floor.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ten_floor.Name = "ten_floor";
            this.ten_floor.Size = new System.Drawing.Size(104, 42);
            this.ten_floor.TabIndex = 9;
            this.ten_floor.Text = "10樓";
            this.ten_floor.UseVisualStyleBackColor = false;
            // 
            // nine_floor
            // 
            this.nine_floor.AutoSize = true;
            this.nine_floor.BackColor = System.Drawing.Color.Transparent;
            this.nine_floor.Location = new System.Drawing.Point(755, 69);
            this.nine_floor.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.nine_floor.Name = "nine_floor";
            this.nine_floor.Size = new System.Drawing.Size(86, 42);
            this.nine_floor.TabIndex = 8;
            this.nine_floor.Text = "9樓";
            this.nine_floor.UseVisualStyleBackColor = false;
            // 
            // three_floor
            // 
            this.three_floor.AutoSize = true;
            this.three_floor.BackColor = System.Drawing.Color.Transparent;
            this.three_floor.Location = new System.Drawing.Point(189, 69);
            this.three_floor.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.three_floor.Name = "three_floor";
            this.three_floor.Size = new System.Drawing.Size(86, 42);
            this.three_floor.TabIndex = 7;
            this.three_floor.Text = "3樓";
            this.three_floor.UseVisualStyleBackColor = false;
            // 
            // four_floor
            // 
            this.four_floor.AutoSize = true;
            this.four_floor.BackColor = System.Drawing.Color.Transparent;
            this.four_floor.Location = new System.Drawing.Point(283, 69);
            this.four_floor.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.four_floor.Name = "four_floor";
            this.four_floor.Size = new System.Drawing.Size(86, 42);
            this.four_floor.TabIndex = 6;
            this.four_floor.Text = "4樓";
            this.four_floor.UseVisualStyleBackColor = false;
            // 
            // six_floor
            // 
            this.six_floor.AutoSize = true;
            this.six_floor.BackColor = System.Drawing.Color.Transparent;
            this.six_floor.Location = new System.Drawing.Point(477, 69);
            this.six_floor.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.six_floor.Name = "six_floor";
            this.six_floor.Size = new System.Drawing.Size(86, 42);
            this.six_floor.TabIndex = 5;
            this.six_floor.Text = "6樓";
            this.six_floor.UseVisualStyleBackColor = false;
            // 
            // seven_floor
            // 
            this.seven_floor.AutoSize = true;
            this.seven_floor.BackColor = System.Drawing.Color.Transparent;
            this.seven_floor.Location = new System.Drawing.Point(571, 69);
            this.seven_floor.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.seven_floor.Name = "seven_floor";
            this.seven_floor.Size = new System.Drawing.Size(86, 42);
            this.seven_floor.TabIndex = 4;
            this.seven_floor.Text = "7樓";
            this.seven_floor.UseVisualStyleBackColor = false;
            // 
            // eight_floor
            // 
            this.eight_floor.AutoSize = true;
            this.eight_floor.BackColor = System.Drawing.Color.Transparent;
            this.eight_floor.Location = new System.Drawing.Point(661, 69);
            this.eight_floor.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.eight_floor.Name = "eight_floor";
            this.eight_floor.Size = new System.Drawing.Size(86, 42);
            this.eight_floor.TabIndex = 3;
            this.eight_floor.Text = "8樓";
            this.eight_floor.UseVisualStyleBackColor = false;
            // 
            // five_floor
            // 
            this.five_floor.AutoSize = true;
            this.five_floor.BackColor = System.Drawing.Color.Transparent;
            this.five_floor.Location = new System.Drawing.Point(387, 69);
            this.five_floor.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.five_floor.Name = "five_floor";
            this.five_floor.Size = new System.Drawing.Size(86, 42);
            this.five_floor.TabIndex = 2;
            this.five_floor.Text = "5樓";
            this.five_floor.UseVisualStyleBackColor = false;
            // 
            // two_floor
            // 
            this.two_floor.AutoSize = true;
            this.two_floor.BackColor = System.Drawing.Color.Transparent;
            this.two_floor.Location = new System.Drawing.Point(99, 69);
            this.two_floor.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.two_floor.Name = "two_floor";
            this.two_floor.Size = new System.Drawing.Size(86, 42);
            this.two_floor.TabIndex = 1;
            this.two_floor.Text = "2樓";
            this.two_floor.UseVisualStyleBackColor = false;
            // 
            // one_floor
            // 
            this.one_floor.AutoSize = true;
            this.one_floor.BackColor = System.Drawing.Color.Transparent;
            this.one_floor.Checked = true;
            this.one_floor.Location = new System.Drawing.Point(5, 69);
            this.one_floor.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.one_floor.Name = "one_floor";
            this.one_floor.Size = new System.Drawing.Size(86, 42);
            this.one_floor.TabIndex = 0;
            this.one_floor.TabStop = true;
            this.one_floor.Text = "1樓";
            this.one_floor.UseVisualStyleBackColor = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.down);
            this.groupBox2.Controls.Add(this.up);
            this.groupBox2.Controls.Add(this.comboBox2);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Enabled = false;
            this.groupBox2.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox2.Location = new System.Drawing.Point(75, 191);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Size = new System.Drawing.Size(252, 391);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "電梯外部控制";
            // 
            // down
            // 
            this.down.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.down.ForeColor = System.Drawing.Color.Black;
            this.down.Location = new System.Drawing.Point(75, 264);
            this.down.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.down.Name = "down";
            this.down.Size = new System.Drawing.Size(83, 60);
            this.down.TabIndex = 8;
            this.down.Text = "下";
            this.down.UseVisualStyleBackColor = false;
            this.down.Click += new System.EventHandler(this.down_Click);
            // 
            // up
            // 
            this.up.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.up.ForeColor = System.Drawing.Color.Black;
            this.up.Location = new System.Drawing.Point(75, 182);
            this.up.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.up.Name = "up";
            this.up.Size = new System.Drawing.Size(83, 60);
            this.up.TabIndex = 7;
            this.up.Text = "上";
            this.up.UseVisualStyleBackColor = false;
            this.up.Click += new System.EventHandler(this.up_Click);
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "1樓",
            "2樓",
            "3樓",
            "4樓",
            "5樓",
            "6樓",
            "7樓",
            "8樓",
            "9樓",
            "10樓"});
            this.comboBox2.Location = new System.Drawing.Point(37, 112);
            this.comboBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(181, 37);
            this.comboBox2.TabIndex = 6;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(68, 48);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(110, 31);
            this.label9.TabIndex = 4;
            this.label9.Text = "目前樓層";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.close_door);
            this.groupBox3.Controls.Add(this.groupBox5);
            this.groupBox3.Controls.Add(this.open_door);
            this.groupBox3.Enabled = false;
            this.groupBox3.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox3.Location = new System.Drawing.Point(413, 191);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox3.Size = new System.Drawing.Size(267, 456);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "電梯內部控制";
            // 
            // close_door
            // 
            this.close_door.AutoSize = true;
            this.close_door.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.close_door.Checked = true;
            this.close_door.Enabled = false;
            this.close_door.ForeColor = System.Drawing.Color.Black;
            this.close_door.Location = new System.Drawing.Point(145, 398);
            this.close_door.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.close_door.Name = "close_door";
            this.close_door.Size = new System.Drawing.Size(83, 35);
            this.close_door.TabIndex = 1;
            this.close_door.TabStop = true;
            this.close_door.Text = "關門";
            this.close_door.UseVisualStyleBackColor = false;
            this.close_door.CheckedChanged += new System.EventHandler(this.close_door_CheckedChanged);
            this.close_door.Click += new System.EventHandler(this.close_door_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.groupBox5.Controls.Add(this.ten_chance);
            this.groupBox5.Controls.Add(this.nine_chance);
            this.groupBox5.Controls.Add(this.three_chance);
            this.groupBox5.Controls.Add(this.four_chance);
            this.groupBox5.Controls.Add(this.six_chance);
            this.groupBox5.Controls.Add(this.seven_chance);
            this.groupBox5.Controls.Add(this.eight_chance);
            this.groupBox5.Controls.Add(this.five_chance);
            this.groupBox5.Controls.Add(this.two_chance);
            this.groupBox5.Controls.Add(this.one_chance);
            this.groupBox5.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox5.ForeColor = System.Drawing.Color.Black;
            this.groupBox5.Location = new System.Drawing.Point(40, 48);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox5.Size = new System.Drawing.Size(188, 312);
            this.groupBox5.TabIndex = 1;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "請選擇樓層";
            // 
            // ten_chance
            // 
            this.ten_chance.AutoCheck = false;
            this.ten_chance.AutoSize = true;
            this.ten_chance.BackColor = System.Drawing.Color.Transparent;
            this.ten_chance.Location = new System.Drawing.Point(99, 261);
            this.ten_chance.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ten_chance.Name = "ten_chance";
            this.ten_chance.Size = new System.Drawing.Size(77, 29);
            this.ten_chance.TabIndex = 9;
            this.ten_chance.Text = "10樓";
            this.ten_chance.UseVisualStyleBackColor = false;
            this.ten_chance.Click += new System.EventHandler(this.ten_chance_Click);
            // 
            // nine_chance
            // 
            this.nine_chance.AutoCheck = false;
            this.nine_chance.AutoSize = true;
            this.nine_chance.BackColor = System.Drawing.Color.Transparent;
            this.nine_chance.Location = new System.Drawing.Point(99, 216);
            this.nine_chance.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.nine_chance.Name = "nine_chance";
            this.nine_chance.Size = new System.Drawing.Size(65, 29);
            this.nine_chance.TabIndex = 8;
            this.nine_chance.Text = "9樓";
            this.nine_chance.UseVisualStyleBackColor = false;
            this.nine_chance.Click += new System.EventHandler(this.nine_chance_Click);
            // 
            // three_chance
            // 
            this.three_chance.AutoCheck = false;
            this.three_chance.AutoSize = true;
            this.three_chance.BackColor = System.Drawing.Color.Transparent;
            this.three_chance.Location = new System.Drawing.Point(5, 165);
            this.three_chance.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.three_chance.Name = "three_chance";
            this.three_chance.Size = new System.Drawing.Size(65, 29);
            this.three_chance.TabIndex = 7;
            this.three_chance.Text = "3樓";
            this.three_chance.UseVisualStyleBackColor = false;
            this.three_chance.Click += new System.EventHandler(this.three_chance_Click);
            // 
            // four_chance
            // 
            this.four_chance.AutoCheck = false;
            this.four_chance.AutoSize = true;
            this.four_chance.BackColor = System.Drawing.Color.Transparent;
            this.four_chance.Location = new System.Drawing.Point(5, 212);
            this.four_chance.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.four_chance.Name = "four_chance";
            this.four_chance.Size = new System.Drawing.Size(65, 29);
            this.four_chance.TabIndex = 6;
            this.four_chance.Text = "4樓";
            this.four_chance.UseVisualStyleBackColor = false;
            this.four_chance.Click += new System.EventHandler(this.four_chance_Click);
            // 
            // six_chance
            // 
            this.six_chance.AutoCheck = false;
            this.six_chance.AutoSize = true;
            this.six_chance.BackColor = System.Drawing.Color.Transparent;
            this.six_chance.Location = new System.Drawing.Point(99, 69);
            this.six_chance.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.six_chance.Name = "six_chance";
            this.six_chance.Size = new System.Drawing.Size(65, 29);
            this.six_chance.TabIndex = 5;
            this.six_chance.Text = "6樓";
            this.six_chance.UseVisualStyleBackColor = false;
            this.six_chance.Click += new System.EventHandler(this.six_chance_Click);
            // 
            // seven_chance
            // 
            this.seven_chance.AutoCheck = false;
            this.seven_chance.AutoSize = true;
            this.seven_chance.BackColor = System.Drawing.Color.Transparent;
            this.seven_chance.Location = new System.Drawing.Point(99, 118);
            this.seven_chance.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.seven_chance.Name = "seven_chance";
            this.seven_chance.Size = new System.Drawing.Size(65, 29);
            this.seven_chance.TabIndex = 4;
            this.seven_chance.Text = "7樓";
            this.seven_chance.UseVisualStyleBackColor = false;
            this.seven_chance.Click += new System.EventHandler(this.seven_chance_Click);
            // 
            // eight_chance
            // 
            this.eight_chance.AutoCheck = false;
            this.eight_chance.AutoSize = true;
            this.eight_chance.BackColor = System.Drawing.Color.Transparent;
            this.eight_chance.Location = new System.Drawing.Point(99, 168);
            this.eight_chance.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.eight_chance.Name = "eight_chance";
            this.eight_chance.Size = new System.Drawing.Size(65, 29);
            this.eight_chance.TabIndex = 3;
            this.eight_chance.Text = "8樓";
            this.eight_chance.UseVisualStyleBackColor = false;
            this.eight_chance.Click += new System.EventHandler(this.eight_chance_Click);
            // 
            // five_chance
            // 
            this.five_chance.AutoCheck = false;
            this.five_chance.AutoSize = true;
            this.five_chance.BackColor = System.Drawing.Color.Transparent;
            this.five_chance.Location = new System.Drawing.Point(5, 261);
            this.five_chance.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.five_chance.Name = "five_chance";
            this.five_chance.Size = new System.Drawing.Size(65, 29);
            this.five_chance.TabIndex = 2;
            this.five_chance.Text = "5樓";
            this.five_chance.UseVisualStyleBackColor = false;
            this.five_chance.Click += new System.EventHandler(this.five_chance_Click);
            // 
            // two_chance
            // 
            this.two_chance.AutoCheck = false;
            this.two_chance.AutoSize = true;
            this.two_chance.BackColor = System.Drawing.Color.Transparent;
            this.two_chance.Location = new System.Drawing.Point(5, 118);
            this.two_chance.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.two_chance.Name = "two_chance";
            this.two_chance.Size = new System.Drawing.Size(65, 29);
            this.two_chance.TabIndex = 1;
            this.two_chance.Text = "2樓";
            this.two_chance.UseVisualStyleBackColor = false;
            this.two_chance.Click += new System.EventHandler(this.two_chance_Click);
            // 
            // one_chance
            // 
            this.one_chance.AutoCheck = false;
            this.one_chance.AutoSize = true;
            this.one_chance.BackColor = System.Drawing.Color.Transparent;
            this.one_chance.Location = new System.Drawing.Point(5, 69);
            this.one_chance.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.one_chance.Name = "one_chance";
            this.one_chance.Size = new System.Drawing.Size(65, 29);
            this.one_chance.TabIndex = 0;
            this.one_chance.TabStop = true;
            this.one_chance.Text = "1樓";
            this.one_chance.UseVisualStyleBackColor = false;
            this.one_chance.Click += new System.EventHandler(this.one_chance_Click);
            // 
            // open_door
            // 
            this.open_door.AutoSize = true;
            this.open_door.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.open_door.Enabled = false;
            this.open_door.ForeColor = System.Drawing.Color.Black;
            this.open_door.Location = new System.Drawing.Point(40, 398);
            this.open_door.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.open_door.Name = "open_door";
            this.open_door.Size = new System.Drawing.Size(83, 35);
            this.open_door.TabIndex = 0;
            this.open_door.Text = "開門";
            this.open_door.UseVisualStyleBackColor = false;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Controls.Add(this.comboBox1);
            this.groupBox4.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox4.Location = new System.Drawing.Point(811, 191);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox4.Size = new System.Drawing.Size(252, 262);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "電梯設定";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(61, 92);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 31);
            this.label1.TabIndex = 1;
            this.label1.Text = "設定樓層";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "1樓",
            "2樓",
            "3樓",
            "4樓",
            "5樓",
            "6樓",
            "7樓",
            "8樓",
            "9樓",
            "10樓"});
            this.comboBox1.Location = new System.Drawing.Point(27, 158);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(181, 37);
            this.comboBox1.TabIndex = 0;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(853, 478);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 31);
            this.label2.TabIndex = 4;
            this.label2.Text = "使用步驟";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(785, 521);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(130, 31);
            this.label3.TabIndex = 5;
            this.label3.Text = "1.選擇樓層";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(927, 521);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(130, 31);
            this.label4.TabIndex = 6;
            this.label4.Text = "2.選擇上下";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(808, 592);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(202, 31);
            this.label5.TabIndex = 7;
            this.label5.Text = "1.選擇要去的樓層";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(853, 652);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(110, 31);
            this.label6.TabIndex = 8;
            this.label6.Text = "最後關門";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label7.ForeColor = System.Drawing.Color.Silver;
            this.label7.Location = new System.Drawing.Point(895, 562);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 31);
            this.label7.TabIndex = 9;
            this.label7.Text = "OR";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.ClientSize = new System.Drawing.Size(1133, 706);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "電梯模擬";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton ten_floor;
        private System.Windows.Forms.RadioButton nine_floor;
        private System.Windows.Forms.RadioButton three_floor;
        private System.Windows.Forms.RadioButton four_floor;
        private System.Windows.Forms.RadioButton six_floor;
        private System.Windows.Forms.RadioButton seven_floor;
        private System.Windows.Forms.RadioButton eight_floor;
        private System.Windows.Forms.RadioButton five_floor;
        private System.Windows.Forms.RadioButton two_floor;
        private System.Windows.Forms.RadioButton one_floor;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton close_door;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.RadioButton ten_chance;
        private System.Windows.Forms.RadioButton nine_chance;
        private System.Windows.Forms.RadioButton three_chance;
        private System.Windows.Forms.RadioButton four_chance;
        private System.Windows.Forms.RadioButton six_chance;
        private System.Windows.Forms.RadioButton seven_chance;
        private System.Windows.Forms.RadioButton eight_chance;
        private System.Windows.Forms.RadioButton five_chance;
        private System.Windows.Forms.RadioButton two_chance;
        private System.Windows.Forms.RadioButton one_chance;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Button down;
        private System.Windows.Forms.Button up;
        private System.Windows.Forms.RadioButton open_door;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Timer timer1;
    }
}

