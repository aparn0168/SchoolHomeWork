﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace elevator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        byte[] outele_state = new byte[11]; //外部狀態列
        //1.上
        //2.下
        //3.上下
        //7.無
        
        byte[] insele_state = new byte[11]; //內部狀態列
        //1.有
        //7.無

        byte nowele_state = 7;//電梯狀態
        //1.上
        //2.下
        //7.停

        int nowele_level;//電梯樓層
        private void Form1_Load(object sender, EventArgs e)
        {

            for(int i =1; i< 10; i++)
            {
                outele_state[i] = 7;
                insele_state[i] = 7;
            }
            nowele_state = 7;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            groupBox2.Enabled = true;
            groupBox3.Enabled = true;

            nowele_level = comboBox1.SelectedIndex + 1;
            ele_up_down_change();
        }

       

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox2.SelectedIndex == 0) down.Enabled = false;
            if (comboBox2.SelectedIndex == 9) up.Enabled = false;
            up.Enabled = true;
            down.Enabled = true;
            if (comboBox2.SelectedIndex + 1 == nowele_level)
            {
                up.Enabled = false;
                down.Enabled = false;
            }
            chancecolor();
        }

        private void chancecolor()
        {
            upstat = false;
            downstat = false;
            updowncolochance();

           
            if (outele_state[comboBox2.SelectedIndex + 1] == 1)
            {
                upstat = true;
                downstat = false;
                updowncolochance();
            }
            else if (outele_state[comboBox2.SelectedIndex + 1] == 2)
            {
                upstat = false;
                downstat = true;
                updowncolochance();
            }
            else if (outele_state[comboBox2.SelectedIndex + 1] == 3)
            {
                upstat = true;
                downstat = true;
                updowncolochance();
            }
            else if (outele_state[comboBox2.SelectedIndex + 1] == 7)
            {
                upstat = false;
                downstat = false;
                updowncolochance();
            }
        }
        

        private void ele_up_down_change()
        {
            switch (nowele_level)
            {
                case 1:
                    one_floor.Checked = true;
                    break;
                case 2:
                    two_floor.Checked = true;
                    break;
                case 3:
                    three_floor.Checked = true;
                    break;
                case 4:
                    four_floor.Checked = true;
                    break;
                case 5:
                    five_floor.Checked = true;
                    break;
                case 6:
                    six_floor.Checked = true;
                    break;
                case 7:
                    seven_floor.Checked = true;
                    break;
                case 8:
                    eight_floor.Checked = true;
                    break;
                case 9:
                    nine_floor.Checked = true;
                    break;
                case 10:
                    ten_floor.Checked = true;
                    break;
            }
        }

         private void updowncolochance()
        {
            if (upstat)
            {
                up.BackColor = Color.Yellow;
            }
            else
            {
                up.BackColor = Color.Cyan;
            }

            if (downstat)
            {
                down.BackColor = Color.Yellow;
            }
            else
            {
                down.BackColor = Color.Cyan;
            }
        }
        bool upstat = false;
        bool downstat = false;
        int x = 1;
        private void up_Click(object sender, EventArgs e)
        {
            if (nowele_state == 3 && open_door.Checked) close_door.Checked = true;
            if(comboBox2.SelectedIndex == 9) { }
            else upstat = !upstat;
            updowncolochance();
            if (upstat && !downstat) outele_state[comboBox2.SelectedIndex + 1] = 1;
            else if (!upstat && downstat) outele_state[comboBox2.SelectedIndex + 1] = 2;
            else if (upstat && downstat) outele_state[comboBox2.SelectedIndex + 1] = 3;
            else if (!upstat && !downstat) outele_state[comboBox2.SelectedIndex + 1] = 7;
        }

        private void down_Click(object sender, EventArgs e)
        {
            if (nowele_state == 3 && open_door.Checked) close_door.Checked = true;
            if (comboBox2.SelectedIndex == 0) { }
            else downstat = !downstat;
            updowncolochance();
            if (upstat && !downstat) outele_state[comboBox2.SelectedIndex + 1] = 1;
            else if (!upstat && downstat) outele_state[comboBox2.SelectedIndex + 1] = 2;
            else if (upstat && downstat) outele_state[comboBox2.SelectedIndex + 1] = 3;
            else if (!upstat && !downstat) outele_state[comboBox2.SelectedIndex + 1] = 7;
        }

        private void close_door_Click(object sender, EventArgs e)
        {
           
        }
        private bool havechance() //還有燈 true   沒有燈 false  判斷整體電梯是否有燈
        {
            for(int i =1; i<=10; i++)
            {
                if (outele_state[i] == 1 || outele_state[i] == 2 || outele_state[i] == 3) return true;
                if (insele_state[i] == 1) return true;
            }
            return false;
        }

        private bool uptest(int x) //判斷上面是否還有燈  還有 true  沒有false
        {
            for(int i =x+1; i <= 10; i++)
            {
                if (outele_state[i] == 1 || outele_state[i] == 2 || outele_state[i] == 3) return true;
                if (insele_state[i] == 1) return true;
            }
            return false;
        }

        private bool downtest(int x) //判斷下面是否還有燈  還有 true  沒有false
        {
            for (int i = x-1; i >= 1; i--)
            {
                if (outele_state[i] == 1 || outele_state[i] == 2 || outele_state[i] == 3) return true;
                if (insele_state[i] == 1) return true;
            }
            return false;
        }

        private void elemove(int x)
        {
            up.Enabled = true;
            down.Enabled = true;
            if (comboBox2.SelectedIndex + 1 == nowele_level)
            {
                up.Enabled = false;
                down.Enabled = false;
            }
           open_door.Checked = true;
            if(!havechance()) this.Refresh();
            bool stop = false;
            switch (x)
            {
                case 1:
                    stop = false;
                    insele_state[x] = 7;
                    if (one_chance.Checked)
                    {
                        stop = true;
                        one_chance.Checked = false;
                        insele_state[x] = 7;
                    }
                    if (outele_state[x] == 1 && nowele_state == 1) //外部控制上升 電梯狀態上升
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    if (outele_state[x] == 2 && nowele_state == 2)  //外部控制下降 電梯狀態下降或停止
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    if (outele_state[x] == 3 && (nowele_state == 2 || nowele_state == 7))  //外部控制全按 電梯狀態上升
                    {
                        stop = true;
                        outele_state[x] = 2;  //燈號留下
                    }
                    if (outele_state[x] == 3 && nowele_state == 2)  //外部控制全按 電梯狀態下降
                    {
                        stop = true;
                        outele_state[x] = 1;  //燈號留上
                    }
                    if (outele_state[x] == 1 && nowele_state == 2 && !downtest(x))//外部控制上升 電梯狀態下降 而且下面沒東西
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    if (outele_state[x] == 2 && nowele_state == 1 && !uptest(x))//外部控制下降 電梯狀態上升 而且上面沒東西
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    chancecolor();
                    if (stop)
                    {
                        MessageBox.Show("一樓到了", "樓層提示");
                        Thread.Sleep(5000);
                    }

                    break;
                case 2:
                    stop = false;
                    insele_state[x] = 7;
                    if (two_chance.Checked)
                    {
                        stop = true;
                        two_chance.Checked = false;
                        insele_state[x] = 7;
                    }

                    if (outele_state[x] == 1 && nowele_state == 1) //外部控制上升 電梯狀態上升
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    if (outele_state[x] == 2 && nowele_state == 2)  //外部控制下降 電梯狀態下降或停止
                    { 
                        stop = true;
                        outele_state[x] = 7;
                    }
                    if (outele_state[x] == 3 && (nowele_state == 2 || nowele_state == 7))  //外部控制全按 電梯狀態上升
                    {
                        stop = true;
                        outele_state[x] = 2;  //燈號留下
                    }
                    if (outele_state[x] == 3 && nowele_state == 2)  //外部控制全按 電梯狀態下降
                    {
                        stop = true;
                        outele_state[x] = 1;  //燈號留上
                    }
                    if(outele_state[x] == 1 && nowele_state == 2 && !downtest(x))//外部控制上升 電梯狀態下降 而且下面沒東西
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    if (outele_state[x] == 2 && nowele_state == 1 && !uptest(x))//外部控制下降 電梯狀態上升 而且上面沒東西
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    chancecolor();
                    if (stop)
                    {
                        if (stop) MessageBox.Show("二樓到了", "樓層提示");
                        Thread.Sleep(5000);
                    }
                    

                    break;
                case 3:
                    stop = false;
                    insele_state[x] = 7;
                    if (three_chance.Checked)
                    {
                        stop = true;
                        three_chance.Checked = false;
                        insele_state[x] = 7;
                    }
                    if (outele_state[x] == 1 && nowele_state == 1) //外部控制上升 電梯狀態上升
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    if (outele_state[x] == 2 && nowele_state == 2)  //外部控制下降 電梯狀態下降
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    if (outele_state[x] == 3 && nowele_state == 1)  //外部控制全按 電梯狀態上升
                    {
                        stop = true;
                        outele_state[x] = 2;  //燈號留下
                    }
                    if (outele_state[x] == 3 && nowele_state == 2)  //外部控制全按 電梯狀態下降
                    {
                        stop = true;
                        outele_state[x] = 1;  //燈號留上
                    }
                    if (outele_state[x] == 1 && nowele_state == 2 && !downtest(x))//外部控制上升 電梯狀態下降 而且下面沒東西
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    if (outele_state[x] == 2 && nowele_state == 1 && !uptest(x))//外部控制下降 電梯狀態上升 而且上面沒東西
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    chancecolor();
                    if (stop)
                    {
                        if (stop) MessageBox.Show("三樓到了", "樓層提示");
                        Thread.Sleep(5000);
                    }
                    break;
                case 4:
                    stop = false;
                    insele_state[x] = 7;
                    if (four_chance.Checked)
                    {
                        stop = true;
                        four_chance.Checked = false;
                        insele_state[x] = 7;
                    }
                    if (outele_state[x] == 1 && nowele_state == 1) //外部控制上升 電梯狀態上升
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    if (outele_state[x] == 2 && nowele_state == 2)  //外部控制下降 電梯狀態下降
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    if (outele_state[x] == 3 && nowele_state == 1)  //外部控制全按 電梯狀態上升
                    {
                        stop = true;
                        outele_state[x] = 2;  //燈號留下
                    }
                    if (outele_state[x] == 3 && nowele_state == 2)  //外部控制全按 電梯狀態下降
                    {
                        stop = true;
                        outele_state[x] = 1;  //燈號留上
                    }
                    if (outele_state[x] == 1 && nowele_state == 2 && !downtest(x))//外部控制上升 電梯狀態下降 而且下面沒東西
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    if (outele_state[x] == 2 && nowele_state == 1 && !uptest(x))//外部控制下降 電梯狀態上升 而且上面沒東西
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    chancecolor();
                    if (stop)
                    {
                        if (stop) MessageBox.Show("四樓到了", "樓層提示");
                        Thread.Sleep(5000);
                    }

                    break;
                case 5:
                    stop = false;
                    insele_state[x] = 7;
                    if (five_chance.Checked)
                    {
                        stop = true;
                        five_chance.Checked = false;
                        insele_state[x] = 7;
                    }
                    if (outele_state[x] == 1 && nowele_state == 1) //外部控制上升 電梯狀態上升
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    if (outele_state[x] == 2 && nowele_state == 2)  //外部控制下降 電梯狀態下降
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    if (outele_state[x] == 3 && nowele_state == 1)  //外部控制全按 電梯狀態上升
                    {
                        stop = true;
                        outele_state[x] = 2;  //燈號留下
                    }
                    if (outele_state[x] == 3 && nowele_state == 2)  //外部控制全按 電梯狀態下降
                    {
                        stop = true;
                        outele_state[x] = 1;  //燈號留上
                    }
                    if (outele_state[x] == 1 && nowele_state == 2 && !downtest(x))//外部控制上升 電梯狀態下降 而且下面沒東西
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    if (outele_state[x] == 2 && nowele_state == 1 && !uptest(x))//外部控制下降 電梯狀態上升 而且上面沒東西
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    chancecolor();
                    if (stop)
                    {
                        if (stop) MessageBox.Show("五樓到了", "樓層提示");
                        Thread.Sleep(5000);
                    }
                   
                    break;
                case 6:
                    stop = false;
                    insele_state[x] = 7;
                    if (six_chance.Checked)
                    {
                        stop = true;
                        six_chance.Checked = false;
                        insele_state[x] = 7;
                    }
                    if (outele_state[x] == 1 && nowele_state == 1) //外部控制上升 電梯狀態上升
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    if (outele_state[x] == 2 && nowele_state == 2)  //外部控制下降 電梯狀態下降
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    if (outele_state[x] == 3 && nowele_state == 1)  //外部控制全按 電梯狀態上升
                    {
                        stop = true;
                        outele_state[x] = 2;  //燈號留下
                    }
                    if (outele_state[x] == 3 && nowele_state == 2)  //外部控制全按 電梯狀態下降
                    {
                        stop = true;
                        outele_state[x] = 1;  //燈號留上
                    }
                    if (outele_state[x] == 1 && nowele_state == 2 && !downtest(x))//外部控制上升 電梯狀態下降 而且下面沒東西
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    if (outele_state[x] == 2 && nowele_state == 1 && !uptest(x))//外部控制下降 電梯狀態上升 而且上面沒東西
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    chancecolor();
                    if (stop)
                    {
                        if (stop) MessageBox.Show("六樓到了", "樓層提示");
                        Thread.Sleep(5000);
                    }
                
                    break;
                case 7:
                    stop = false;
                    insele_state[x] = 7;
                    if (seven_chance.Checked)
                    {
                        stop = true;
                        seven_chance.Checked = false;
                        insele_state[x] = 7;
                    }
                    if (outele_state[x] == 1 && nowele_state == 1) //外部控制上升 電梯狀態上升
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    if (outele_state[x] == 2 && nowele_state == 2)  //外部控制下降 電梯狀態下降
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    if (outele_state[x] == 3 && nowele_state == 1)  //外部控制全按 電梯狀態上升
                    {
                        stop = true;
                        outele_state[x] = 2;  //燈號留下
                    }
                    if (outele_state[x] == 3 && nowele_state == 2)  //外部控制全按 電梯狀態下降
                    {
                        stop = true;
                        outele_state[x] = 1;  //燈號留上
                    }
                    if (outele_state[x] == 1 && nowele_state == 2 && !downtest(x))//外部控制上升 電梯狀態下降 而且下面沒東西
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    if (outele_state[x] == 2 && nowele_state == 1 && !uptest(x))//外部控制下降 電梯狀態上升 而且上面沒東西
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    chancecolor();
                    if (stop)
                    {
                        if (stop) MessageBox.Show("七樓到了", "樓層提示");
                        Thread.Sleep(5000);
                    }
                 
                    break;
                case 8:
                    stop = false;
                    insele_state[x] = 7;
                    if (eight_chance.Checked)
                    {
                        stop = true;
                        eight_chance.Checked = false;
                        insele_state[x] = 7;
                    }
                    if (outele_state[x] == 1 && nowele_state == 1) //外部控制上升 電梯狀態上升
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    if (outele_state[x] == 2 && nowele_state == 2)  //外部控制下降 電梯狀態下降
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    if (outele_state[x] == 3 && nowele_state == 1)  //外部控制全按 電梯狀態上升
                    {
                        stop = true;
                        outele_state[x] = 2;  //燈號留下
                    }
                    if (outele_state[x] == 3 && nowele_state == 2)  //外部控制全按 電梯狀態下降
                    {
                        stop = true;
                        outele_state[x] = 1;  //燈號留上
                    }
                    if (outele_state[x] == 1 && nowele_state == 2 && !downtest(x))//外部控制上升 電梯狀態下降 而且下面沒東西
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    if (outele_state[x] == 2 && nowele_state == 1 && !uptest(x))//外部控制下降 電梯狀態上升 而且上面沒東西
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    chancecolor();
                    if (stop)
                    {
                        if (stop) MessageBox.Show("八樓到了", "樓層提示");
                        Thread.Sleep(5000);
                    }
                  
                    break;
                case 9:
                    insele_state[x] = 7;
                    stop = false;
                    if (nine_chance.Checked)
                    {
                        stop = true;
                        nine_chance.Checked = false;
                        insele_state[x] = 7;
                    }
                    if (outele_state[x] == 1 && nowele_state == 1) //外部控制上升 電梯狀態上升
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    if (outele_state[x] == 2 && nowele_state == 2)  //外部控制下降 電梯狀態下降
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    if (outele_state[x] == 3 && nowele_state == 1)  //外部控制全按 電梯狀態上升
                    {
                        stop = true;
                        outele_state[x] = 2;  //燈號留下
                    }
                    if (outele_state[x] == 3 && nowele_state == 2)  //外部控制全按 電梯狀態下降 
                    {
                        stop = true;
                        outele_state[x] = 1;  //燈號留上
                    }
                    if (outele_state[x] == 1 && nowele_state == 2 && !downtest(x))//外部控制上升 電梯狀態下降 而且下面沒東西
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    if (outele_state[x] == 2 && nowele_state == 1 && !uptest(x))//外部控制下降 電梯狀態上升 而且上面沒東西
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    chancecolor();
                    if (stop)
                    {
                        if (stop) MessageBox.Show("九樓到了", "樓層提示");
                        Thread.Sleep(5000);
                    }
                   
                    break;
                case 10:
                    stop = false;
                    insele_state[x] = 7;
                    if (ten_chance.Checked)
                    {
                        stop = true;
                        ten_chance.Checked = false;
                        insele_state[x] = 7;
                    }

                    if (outele_state[x] == 1 && nowele_state == 1) //外部控制上升 電梯狀態上升
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    if (outele_state[x] == 2 && nowele_state == 2)  //外部控制下降 電梯狀態下降或停止
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    if (outele_state[x] == 3 && (nowele_state == 2 || nowele_state == 7))  //外部控制全按 電梯狀態上升
                    {
                        stop = true;
                        outele_state[x] = 2;  //燈號留下
                    }
                    if (outele_state[x] == 3 && nowele_state == 2)  //外部控制全按 電梯狀態下降
                    {
                        stop = true;
                        outele_state[x] = 1;  //燈號留上
                    }
                    if (outele_state[x] == 1 && nowele_state == 2 && !downtest(x))//外部控制上升 電梯狀態下降 而且下面沒東西
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    if (outele_state[x] == 2 && nowele_state == 1 && !uptest(x))//外部控制下降 電梯狀態上升 而且上面沒東西
                    {
                        stop = true;
                        outele_state[x] = 7;
                    }
                    chancecolor();
                    if (stop)
                    {
                        if (stop) MessageBox.Show("十樓到了", "樓層提示");
                        Thread.Sleep(5000);
                    }
               
                    break;
                default:
                    break;
            }
            close_door.Checked = true;
        }

        private void one_chance_Click(object sender, EventArgs e)
        {
            if (nowele_level == 1) return;
            one_chance.Checked = !one_chance.Checked;
            if (one_chance.Checked) insele_state[1] = 1;
            else insele_state[1] = 7;
        }

        private void two_chance_Click(object sender, EventArgs e)
        {
            if (nowele_level == 2) return;
            two_chance.Checked = !two_chance.Checked;
            if (two_chance.Checked) insele_state[2] = 1;
            else insele_state[2] = 7;
        }

        private void three_chance_Click(object sender, EventArgs e)
        {
            if (nowele_level == 3) return;
            three_chance.Checked = !three_chance.Checked;
            if (three_chance.Checked) insele_state[3] = 1;
            else insele_state[3] = 7;
        }

        private void four_chance_Click(object sender, EventArgs e)
        {
            if (nowele_level == 4) return;
            four_chance.Checked = !four_chance.Checked;
            if (four_chance.Checked) insele_state[4] = 1;
            else insele_state[4] = 7;
        }

        private void five_chance_Click(object sender, EventArgs e)
        {
            if (nowele_level == 5) return;
            five_chance.Checked = !five_chance.Checked;
            if (five_chance.Checked) insele_state[5] = 1;
            else insele_state[5] = 7;
        }

        private void six_chance_Click(object sender, EventArgs e)
        {
            if (nowele_level == 6) return;
            six_chance.Checked = !six_chance.Checked;
            if (six_chance.Checked) insele_state[6] = 1;
            else insele_state[6] = 7;
        }

        private void seven_chance_Click(object sender, EventArgs e)
        {
            if (nowele_level == 7) return;
            seven_chance.Checked = !seven_chance.Checked;
            if (seven_chance.Checked) insele_state[7] = 1;
            else insele_state[7] = 7;
        }

        private void eight_chance_Click(object sender, EventArgs e)
        {
            if (nowele_level == 8) return;
            eight_chance.Checked = !eight_chance.Checked;
            if (eight_chance.Checked) insele_state[8] = 1;
            else insele_state[8] = 7;
        }

        private void nine_chance_Click(object sender, EventArgs e)
        {
            if (nowele_level == 9) return;
            nine_chance.Checked = !nine_chance.Checked;
            if (nine_chance.Checked) insele_state[9] = 1;
            else insele_state[9] = 7;
        }

        private void ten_chance_Click(object sender, EventArgs e)
        {
            if (nowele_level == 10) return;
            ten_chance.Checked = !ten_chance.Checked;
            if (ten_chance.Checked) insele_state[10] = 1;
            else insele_state[10] = 7;
        }

        private void close_door_CheckedChanged(object sender, EventArgs e)
        {

        }
        //===================
    
        //===================
        private void timer1_Tick(object sender, EventArgs e)
        {
            Form.CheckForIllegalCrossThreadCalls = false;
            ThreadStart myRun = new ThreadStart(threadjob);
            Thread myThread = new Thread(myRun);

            myThread.Start();
            timer1.Enabled = false;
        }
        private void threadjob()
        {
            while (true)
            {
                job();
            }
            
        }

        private void job()
        {
            for (int i = 1; i <= 299999999; i++) //延時
            {
                decimal s = i * i;
            }

            if (open_door.Checked == true) return;
            if (!havechance()) return;
            while (havechance())
            {


                for (int i = 1; i <= 299999999; i++) //延時
                {
                    decimal s = i * i;
                }


                if (nowele_state == 1)  //電梯狀態上升
                {

                    if (uptest(nowele_level))//上面有東西時
                    {
                        nowele_level++;
                        ele_up_down_change();

                        elemove(nowele_level);
                        //MessageBox.Show("樓層" + nowele_level.ToString() + "狀態" + nowele_state.ToString());
                    }
                    else//上沒有時
                    {
                        if (downtest(nowele_level)) nowele_state = 2;
                        else nowele_state = 7;
                        ele_up_down_change();
                        elemove(nowele_level);
                        continue;
                    }
                }
                else if (nowele_state == 2)//電梯狀態下降
                {

                    if (downtest(nowele_level))//下面有東西時
                    {
                        nowele_level--;
                        ele_up_down_change();
                        elemove(nowele_level);
                        // MessageBox.Show(nowele.ToString());
                    }
                    else//下沒有時
                    {
                        ele_up_down_change();
                        elemove(nowele_level);

                        if (uptest(nowele_level)) nowele_state = 1;
                        else nowele_state = 7;
                        continue;
                    }
                }
                else if (nowele_state == 7)//電梯狀態停止
                {
                    if (uptest(nowele_level))//如上面有東西
                    {
                        nowele_state = 1;
                        continue;
                    }
                    if (downtest(nowele_level))//如下面有東西
                    {
                        nowele_state = 2;
                        continue;
                    }
                    else
                    {
                        close_door.Checked = false;
                        break;
                    }
                }
                else MessageBox.Show("錯誤");
            }
            for (int i = 1; i <= 299999999; i++) //延時
            {
                decimal s = i * i;
            }
            if (x <= 1) open_door.Checked = true;
            x++;

            for (int i = 1; i <= 299999999; i++) //延時
            {
                decimal s = i * i;
            }

            close_door.Checked = true;
            for (int i = 1; i <= 299999999; i++) //延時
            {
                decimal s = i * i;
            }
            if (havechance())
            {
                x = 1;
            }
            timer1.Enabled = true;
            return;
        }
    }
}
